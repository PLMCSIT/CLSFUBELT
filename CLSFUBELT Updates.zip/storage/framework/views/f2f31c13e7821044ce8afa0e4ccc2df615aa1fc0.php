<?php $__env->startSection('event_title'); ?>
<?php echo e($event->event_title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('active'); ?>
<?php echo e($event->event_title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="main" role="main">
  <div id="content" class="content full">
    <div class="container">
      <div class="row">
          <h4>&nbsp;&nbsp;&nbsp;<?php echo e($event->event_desc); ?></h4>

          <div class="col-md-8">
            <div class="panel panel-default">
              <div class="panel-heading">
                <h3 class="panel-title">Event details</h3>
              </div>
              <div class="panel-body">
                <ul class="info-table">
                  <li><i class="fa fa-calendar"></i> <?php echo $event->event_month." ".$event->event_day.", ".$event->event_year; ?></li>
                  <li><i class="fa fa-clock-o"></i> <?php echo e($event->event_time); ?> </li>
                  <li><i class="fa fa-users"> <?php echo e($event->event_type); ?> </i> </li>
                </ul>
              </div>
            </div>
          </div>
            
          <div class="col-md-4">
            <div class="panel panel-default">
              <div class="panel-heading">
                <h3 class="panel-title">Event Status</h3>
              </div>
                <ul class="list-group">
                    <?php
                        $attendees = DB::table('event_users')->where('event_id','=',$event->id)->get()->count();
                    ?>
                  <li class="list-group-item"> <span class="badge"> <?php echo e($attendees); ?> </span> Attendees </li>
                  <?php if(Auth::guest()): ?>
                  <?php else: ?>
                    <?php
                        $id = Auth::user()->id;
                        $joined = false;
                        $event_user_tbl = DB::table('event_users')->where('user_id','=',$id)->where('event_id','=',$event->id)->get();
                    ?>
                    <?php if(empty($event_user_tbl[0])): ?>
                    <a href="<?php echo e(url('event/join')); ?>/<?php echo e($id); ?>/<?php echo e($event->id); ?>" class="btn btn-primary btn-lg btn-block">Join Event</a>
                    <?php else: ?>
                    <a href="<?php echo e(url('event/leave')); ?>/<?php echo e($id); ?>/<?php echo e($event->id); ?>" class="btn btn-primary btn-lg btn-block">Leave Event</a>
                    <?php endif; ?>
                  <?php endif; ?>
                </ul>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.basic', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>