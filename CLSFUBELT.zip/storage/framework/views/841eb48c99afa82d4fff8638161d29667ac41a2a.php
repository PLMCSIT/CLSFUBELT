<div class="modal-content">
<h4><?php echo e($title); ?></h4>
